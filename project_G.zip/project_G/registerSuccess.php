<h1>Rejestracja przebiegła pomyślnie</h1>
<h2>Zaloguj się na podane dane, aby móc zacząć grać!</h2>
<a href="loginForm.php">">ZALOGUJ</a>
<?php

?>